from django.apps import AppConfig


class FacebookMapbotConfig(AppConfig):
    name = 'facebook_mapbot'
